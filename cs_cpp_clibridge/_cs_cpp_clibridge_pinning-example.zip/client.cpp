#pragma comment(lib, "YahooAPIWrapper")
#include <iostream>
#include "YahooAPIWrapper.h"
 
using namespace std;
 
void PrintCB(int* vals) {
    YahooAPIWrapper::test();
    
    for(int i=0; i<4; i++) {
        cout << vals[i] << endl;
    }
}
 
int main()
{

    int* vals = YahooAPIWrapper::GetInts(&PrintCB);
    
    
    return 0;
}